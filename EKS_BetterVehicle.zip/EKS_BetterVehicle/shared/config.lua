Config = {}

Config.Enabled = true
Config.UseMPH = true

Config.AllowedClasses = {
    [0]=true,[1]=true,[2]=true,[3]=true,[4]=true,[5]=true,[6]=true,[7]=true,[9]=true,[10]=true,
    [11]=true,[12]=true,[17]=true,[18]=true,[19]=true,[20]=true
}

-- Smooth launch (no smoke)

Config.DisableHandbrakeWhileHeld = true
Config.DisableBrakeWhileHeldLowSpeed = true
Config.BurnoutBlockSpeed = 10.0

Config.MinTorqueMultiplier = 0.55
Config.MaxTorqueMultiplier = 1.00
Config.RampRate = 6.0
Config.LaunchSpeedStart = 0.0
Config.LaunchSpeedEnd   = 22.0

Config.NoSmokeEnabled = true
Config.NoSmokeSpeed = 14.0
Config.NoSmokeLowSpeedTractionLossMult = 0.0
Config.NoSmokeTractionCurveMaxMult = 1.06
Config.NoSmokeTractionCurveMinMult = 1.04

-- braking

Config.SmoothBrakingEnabled = true
Config.BrakeRampTime = 0.45
Config.BrakeMinMultiplier = 0.35
Config.BrakeMaxMultiplier = 1.00
Config.BrakeReleaseSpeed = 10.0

-- Indicators / hazards

Config.IndicatorsEnabled = true
Config.SteerArmAngle = 12.0
Config.SteerCenterAngle = 4.0
Config.AutoCancelMinSpeed = 6.0

Config.HazardsHoldToEnable = 2.0
Config.HazardsHoldToDisable = 3.0

-- Engine / handbrake

Config.EngineControlEnabled = true
Config.HandbrakeControlEnabled = true

Config.HandbrakeApplyMaxSpeed = 0.6 -- mph (or km/h if UseMPH=false)

-- Engine start animation

Config.EngineStartAnimEnabled = true
Config.EngineStartAnimDict = 'anim@mp_player_intmenu@key_fob@'
Config.EngineStartAnimName = 'fob_click'
Config.EngineStartDelayMs = 450

-- Prevent GTA auto-start on entry (force OFF window if state says OFF)

Config.EntryForceOffMs = 1400

-- Engine keep-alive (prevents engine dropping when you exit)

Config.EngineKeepAliveTickMs = 150
Config.ExitEngineHoldMs = 3500

-- Rolling on hills (REAL hill detection + natural build-up)

Config.RollAssistEnabled = true
Config.RollSampleDistance = 2.2           -- metres forward/back sample
Config.RollMinSlopeAngle = 4.5            -- degrees; higher = only real hills
Config.RollSlopeHoldSeconds = 0.35        -- must be on slope for this long
Config.RollMaxSpeed = 14.0                -- mph max rolling speed (builds up to this)
Config.RollBaseForce = 0.22               -- base "gravity" force (tune if needed)
Config.RollAngleForMaxForce = 12.0        -- degrees where force hits max
