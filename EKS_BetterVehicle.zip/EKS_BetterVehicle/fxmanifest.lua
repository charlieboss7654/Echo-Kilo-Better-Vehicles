fx_version 'cerulean'
game 'gta5'

author 'Cowboy - Echo Kilo Studios'
description 'Smooth Driver'
version '1.0.0'

lua54 'yes'

shared_script 'shared/config.lua'
client_script 'client/client.lua'
