local function clamp(x, a, b)
    if x < a then return a end
    if x > b then return b end
    return x
end

local function lerp(a, b, t)
    return a + (b - a) * t
end

local function getSpeed(veh)
    local ms = GetEntitySpeed(veh)
    if Config.UseMPH then
        return ms * 2.236936
    end
    return ms * 3.6
end

local function isDriver(ped, veh)
    return veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
end

local function classAllowed(veh)
    if Config.AllowedClasses == nil then return true end
    return Config.AllowedClasses[GetVehicleClass(veh)] == true
end

local function vehKey(veh)
    if NetworkGetEntityIsNetworked(veh) then
        local nid = VehToNet(veh)
        if nid and nid > 0 then return ('net:%s'):format(nid) end
    end
    return ('ent:%s'):format(veh)
end

local function safeStateGet(veh, key)
    local ent = Entity(veh)
    if ent and ent.state then return ent.state[key] end
    return nil
end

local function safeStateSet(veh, key, val)
    local ent = Entity(veh)
    if ent and ent.state then
        ent.state:set(key, val, true)
        return true
    end
    return false
end

local function requestAnim(dict)
    if HasAnimDictLoaded(dict) then return true end
    RequestAnimDict(dict)
    local untilTime = GetGameTimer() + 1500
    while not HasAnimDictLoaded(dict) and GetGameTimer() < untilTime do
        Wait(0)
    end
    return HasAnimDictLoaded(dict)
end

local function getGroundZ(x, y, z)
    local ok, gz = GetGroundZFor_3dCoord(x, y, z + 2.0, false)
    if ok then return gz end
    return nil
end

local handlingCache = {}
local function ensureHandlingCached(veh)
    if handlingCache[veh] then return end
    handlingCache[veh] = {
        brakeForce   = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fBrakeForce'),
        lowSpeedLoss = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fLowSpeedTractionLossMult'),
        tMax         = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMax'),
        tMin         = GetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMin'),
    }
end

local function restoreHandling(veh)
    local c = handlingCache[veh]
    if not c or not DoesEntityExist(veh) then return end
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fBrakeForce', c.brakeForce)
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fLowSpeedTractionLossMult', c.lowSpeedLoss)
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMax', c.tMax)
    SetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMin', c.tMin)
end

local activeVeh = 0
local currentTorqueMult = 1.0
local noSmokeApplied = false
local brakeState = 0.0

local leftOn, rightOn, hazardsOn = false, false, false
local leftTurnArmed, leftTurnSeen = false, false
local rightTurnArmed, rightTurnSeen = false, false

local hazardsKeyDown = false
local hazardsHoldStart = 0
local hazardsTriggeredThisHold = false

local smoothKeyDown = false

local engineStates = {}
local engineStatesEnt = {}

local keepEngineAlive = {}
local exitHoldUntil = {}
local entryForceOffUntil = {}
local slopeHold = {}

local function setIndicatorsForVeh(veh)
    if hazardsOn then
        SetVehicleIndicatorLights(veh, 0, true)
        SetVehicleIndicatorLights(veh, 1, true)
        return
    end
    SetVehicleIndicatorLights(veh, 0, leftOn)
    SetVehicleIndicatorLights(veh, 1, rightOn)
end

local function clearLeft()
    leftOn = false
    leftTurnArmed = false
    leftTurnSeen = false
end

local function clearRight()
    rightOn = false
    rightTurnArmed = false
    rightTurnSeen = false
end

local function toggleLeft()
    if not Config.IndicatorsEnabled then return end
    leftOn = not leftOn
    if leftOn then
        clearRight()
        hazardsOn = false
        leftTurnArmed, leftTurnSeen = true, false
    else
        clearLeft()
    end
end

local function toggleRight()
    if not Config.IndicatorsEnabled then return end
    rightOn = not rightOn
    if rightOn then
        clearLeft()
        hazardsOn = false
        rightTurnArmed, rightTurnSeen = true, false
    else
        clearRight()
    end
end

local function getEngineState(veh)
    local s = safeStateGet(veh, 'eks_engine_on')
    if type(s) == 'boolean' then return s end

    local v = engineStatesEnt[veh]
    if type(v) == 'boolean' then return v end

    return engineStates[vehKey(veh)]
end

local function setEngineState(veh, v)
    local ok = safeStateSet(veh, 'eks_engine_on', v)

    engineStatesEnt[veh] = v
    engineStates[vehKey(veh)] = v

    return ok
end


RegisterCommand('eks_left_indicator', function() toggleLeft() end, false)
RegisterCommand('eks_right_indicator', function() toggleRight() end, false)

RegisterCommand('+eks_hazards_hold', function() hazardsKeyDown = true end, false)
RegisterCommand('-eks_hazards_hold', function() hazardsKeyDown = false end, false)

RegisterCommand('+eks_smoothlaunch_hold', function() smoothKeyDown = true end, false)
RegisterCommand('-eks_smoothlaunch_hold', function() smoothKeyDown = false end, false)

RegisterCommand('eks_engine_toggle', function()
    if not Config.EngineControlEnabled then return end

    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 or not isDriver(ped, veh) then return end

    local k = vehKey(veh)
    local cur = getEngineState(veh)
    if cur == nil then cur = false end

    if cur then
        setEngineState(veh, false)
        keepEngineAlive[k] = nil
        exitHoldUntil[k] = nil
        entryForceOffUntil[k] = nil

        SetVehicleUndriveable(veh, true)
        SetVehicleCurrentRpm(veh, 0.0)

        SetVehicleEngineOn(veh, false, true, true)
        Wait(0)
        SetVehicleCurrentRpm(veh, 0.0)
        SetVehicleEngineOn(veh, false, true, true)
        return
    end

    if Config.EngineStartAnimEnabled then
        if requestAnim(Config.EngineStartAnimDict) then
            TaskPlayAnim(ped, Config.EngineStartAnimDict, Config.EngineStartAnimName, 8.0, -8.0, 800, 49, 0.0, false, false, false)
        end
    end

    local delay = tonumber(Config.EngineStartDelayMs) or 450
    if delay > 0 then Wait(delay) end

    setEngineState(veh, true)
    keepEngineAlive[k] = nil
    exitHoldUntil[k] = nil
    entryForceOffUntil[k] = nil

    SetVehicleUndriveable(veh, false)
    SetVehicleEngineOn(veh, true, false, false)
end, false)


RegisterKeyMapping('eks_left_indicator',        'Indicators: Toggle Left',                 'keyboard', 'LEFT')
RegisterKeyMapping('eks_right_indicator',       'Indicators: Toggle Right',                'keyboard', 'RIGHT')
RegisterKeyMapping('+eks_hazards_hold',         'Indicators: Hold to Toggle Hazards',      'keyboard', 'BACK')
RegisterKeyMapping('+eks_smoothlaunch_hold',    'Driving: Smooth Launch (Hold)',           'keyboard', 'LSHIFT')
RegisterKeyMapping('eks_engine_toggle',         'Vehicle: Engine On/Off',                  'keyboard', 'Y')

CreateThread(function()
    while true do
        Wait(0)

        if not Config.IndicatorsEnabled then
            hazardsKeyDown, hazardsTriggeredThisHold, hazardsHoldStart = false, false, 0
            goto continue
        end

        if hazardsKeyDown then
            if hazardsHoldStart == 0 then
                hazardsHoldStart = GetGameTimer()
                hazardsTriggeredThisHold = false
            end

            if not hazardsTriggeredThisHold then
                local heldFor = (GetGameTimer() - hazardsHoldStart) / 1000.0
                local needed = hazardsOn and Config.HazardsHoldToDisable or Config.HazardsHoldToEnable
                if heldFor >= needed then
                    hazardsOn = not hazardsOn
                    hazardsTriggeredThisHold = true
                    if hazardsOn then
                        clearLeft()
                        clearRight()
                    end
                end
            end
        else
            hazardsHoldStart = 0
            hazardsTriggeredThisHold = false
        end

        ::continue::
    end
end)

CreateThread(function()
    local tick = tonumber(Config.EngineKeepAliveTickMs) or 150
    if tick < 80 then tick = 80 end

    while true do
        Wait(tick)

        local now = GetGameTimer()

        for k, veh in pairs(keepEngineAlive) do
            if not veh or veh == 0 or not DoesEntityExist(veh) then
                keepEngineAlive[k] = nil
                exitHoldUntil[k] = nil
            else
                if getEngineState(veh) ~= true then
                    keepEngineAlive[k] = nil
                    exitHoldUntil[k] = nil
                else
                    local hold = exitHoldUntil[k]
                    if hold and now < hold then
                        SetVehicleUndriveable(veh, false)
                        SetVehicleEngineOn(veh, true, true, false)
                    else
                        exitHoldUntil[k] = nil
                        if not GetIsVehicleEngineRunning(veh) then
                            SetVehicleUndriveable(veh, false)
                            SetVehicleEngineOn(veh, true, true, false)
                        end
                    end
                end
            end
        end
    end
end)

local function npcDriverPresent(veh)
    local d = GetPedInVehicleSeat(veh, -1)
    if d ~= 0 and DoesEntityExist(d) and not IsPedAPlayer(d) then
        return true
    end
    return false
end

CreateThread(function()
    local tick = 500
    local radius = 120.0

    while true do
        Wait(tick)
        if not Config.EngineControlEnabled then goto continue end

        local ped = PlayerPedId()
        local pcoords = GetEntityCoords(ped)
        local vehicles = GetGamePool('CVehicle')

        for i = 1, #vehicles do
            local v = vehicles[i]
            if v ~= 0 and DoesEntityExist(v) and npcDriverPresent(v) then
                local vcoords = GetEntityCoords(v)
                if #(pcoords - vcoords) <= radius then
                    SetVehicleUndriveable(v, false)
                    if not GetIsVehicleEngineRunning(v) then
                        SetVehicleEngineOn(v, true, true, false)
                    end
                end
            end
        end

        ::continue::
    end
end)


local wasDriver = false
local lastDriverVeh = 0

CreateThread(function()
    while true do
        Wait(0)

        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        local driverNow = (veh ~= 0 and isDriver(ped, veh))

        if wasDriver and (not driverNow) and lastDriverVeh ~= 0 and DoesEntityExist(lastDriverVeh) then
            local st = getEngineState(lastDriverVeh)
            if st == true then
                local k = vehKey(lastDriverVeh)
                keepEngineAlive[k] = lastDriverVeh
                exitHoldUntil[k] = GetGameTimer() + (tonumber(Config.ExitEngineHoldMs) or 3500)

                SetVehicleUndriveable(lastDriverVeh, false)
                SetVehicleEngineOn(lastDriverVeh, true, true, false)
            end
        end

        if (not wasDriver) and driverNow then
            local st = getEngineState(veh)
            local k = vehKey(veh)

            if st == nil then
                if GetIsVehicleEngineRunning(veh) then
                    st = true
                    setEngineState(veh, true)
                else
                    st = false
                    setEngineState(veh, false)
                end
            end

            if st == false and GetIsVehicleEngineRunning(veh) then
                st = true
                setEngineState(veh, true)
            end

            if st == false then
                entryForceOffUntil[k] = GetGameTimer() + (tonumber(Config.EntryForceOffMs) or 1400)
            else
                keepEngineAlive[k] = nil
                exitHoldUntil[k] = nil
                entryForceOffUntil[k] = nil

                SetVehicleUndriveable(veh, false)
                SetVehicleEngineOn(veh, true, true, false)
            end
        end

        wasDriver = driverNow
        if driverNow then
            lastDriverVeh = veh
        end
    end
end)

CreateThread(function()
    while true do
        Wait(0)

        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)

        if veh == 0 then
            if activeVeh ~= 0 then
                SetVehicleEngineTorqueMultiplier(activeVeh, 1.0)
                restoreHandling(activeVeh)
                FreezeEntityPosition(activeVeh, false)
                activeVeh = 0
                currentTorqueMult = 1.0
                noSmokeApplied = false
                brakeState = 0.0
            end
            goto continue
        end

        if not isDriver(ped, veh) then
            if activeVeh == veh then
                SetVehicleEngineTorqueMultiplier(veh, 1.0)
                restoreHandling(veh)
                FreezeEntityPosition(veh, false)
                activeVeh = 0
                currentTorqueMult = 1.0
                noSmokeApplied = false
                brakeState = 0.0
            end
            goto continue
        end

        if Config.IndicatorsEnabled then
            setIndicatorsForVeh(veh)

            if not hazardsOn then
                local spd = getSpeed(veh)
                local steer = GetVehicleSteeringAngle(veh)

                if leftOn and leftTurnArmed and spd >= Config.AutoCancelMinSpeed then
                    if (not leftTurnSeen) and steer <= -Config.SteerArmAngle then
                        leftTurnSeen = true
                    end
                    if leftTurnSeen and math.abs(steer) <= Config.SteerCenterAngle then
                        clearLeft()
                    end
                end

                if rightOn and rightTurnArmed and spd >= Config.AutoCancelMinSpeed then
                    if (not rightTurnSeen) and steer >= Config.SteerArmAngle then
                        rightTurnSeen = true
                    end
                    if rightTurnSeen and math.abs(steer) <= Config.SteerCenterAngle then
                        clearRight()
                    end
                end
            end
        end

        ensureHandlingCached(veh)
        activeVeh = veh

        if Config.EngineControlEnabled then
            local st = getEngineState(veh)
            if st == nil then
                if GetIsVehicleEngineRunning(veh) then
                    st = true
                    setEngineState(veh, true)
                else
                    st = false
                    setEngineState(veh, false)
                end
            end

            local k = vehKey(veh)
            local forceOffUntil = entryForceOffUntil[k]

            if st == false and GetIsVehicleEngineRunning(veh) then
                st = true
                setEngineState(veh, true)
                entryForceOffUntil[k] = nil
                forceOffUntil = nil
            end

            if st == false or (forceOffUntil and GetGameTimer() < forceOffUntil) then
                SetVehicleUndriveable(veh, true)
                SetVehicleCurrentRpm(veh, 0.0)
                SetVehicleEngineOn(veh, false, true, true)
                DisableControlAction(0, 71, true)
            else
                entryForceOffUntil[k] = nil
                SetVehicleUndriveable(veh, false)
            end
        end

        FreezeEntityPosition(veh, false)

        if (not Config.Enabled) or (not classAllowed(veh)) then
            SetVehicleEngineTorqueMultiplier(veh, 1.0)
            if noSmokeApplied then
                restoreHandling(veh)
                noSmokeApplied = false
            end
            goto continue
        end

        local dt = GetFrameTime()
        local speed = getSpeed(veh)
        local rpm = GetVehicleCurrentRpm(veh) or 0.0

        local accelPressed = IsControlPressed(0, 71)
        local brakePressed = IsControlPressed(0, 72)
        local heldSmooth = smoothKeyDown

        if Config.SmoothBrakingEnabled then
            if brakePressed then
                local inc = dt / math.max(Config.BrakeRampTime, 0.05)
                brakeState = clamp(brakeState + inc, 0.0, 1.0)
            else
                brakeState = clamp(brakeState - (Config.BrakeReleaseSpeed * dt), 0.0, 1.0)
            end

            local c = handlingCache[veh]
            local brakeMult = lerp(Config.BrakeMinMultiplier, Config.BrakeMaxMultiplier, brakeState)
            SetVehicleHandlingFloat(veh, 'CHandlingData', 'fBrakeForce', c.brakeForce * brakeMult)
        end

        if not heldSmooth then
            if noSmokeApplied then
                restoreHandling(veh)
                noSmokeApplied = false
            end
            SetVehicleEngineTorqueMultiplier(veh, 1.0)
            currentTorqueMult = 1.0
            goto continue
        end

        if Config.DisableHandbrakeWhileHeld then
            DisableControlAction(0, 76, true)
        end
        if Config.DisableBrakeWhileHeldLowSpeed and accelPressed and speed <= Config.BurnoutBlockSpeed then
            DisableControlAction(0, 72, true)
        end

        if accelPressed and not brakePressed then
            if Config.NoSmokeEnabled and speed <= Config.NoSmokeSpeed then
                local c = handlingCache[veh]
                SetVehicleHandlingFloat(veh, 'CHandlingData', 'fLowSpeedTractionLossMult', Config.NoSmokeLowSpeedTractionLossMult)
                SetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMax', c.tMax * Config.NoSmokeTractionCurveMaxMult)
                SetVehicleHandlingFloat(veh, 'CHandlingData', 'fTractionCurveMin', c.tMin * Config.NoSmokeTractionCurveMinMult)
                SetVehicleBurnout(veh, false)
                noSmokeApplied = true
            else
                if noSmokeApplied then
                    restoreHandling(veh)
                    noSmokeApplied = false
                end
            end

            local launchZone = clamp(
                (speed - Config.LaunchSpeedStart) / math.max((Config.LaunchSpeedEnd - Config.LaunchSpeedStart), 0.1),
                0.0, 1.0
            )
            local targetTorque = lerp(Config.MinTorqueMultiplier, Config.MaxTorqueMultiplier, launchZone)

            if Config.NoSmokeEnabled and speed <= Config.NoSmokeSpeed and rpm > 0.65 then
                SetVehicleCurrentRpm(veh, 0.60)
                SetVehicleBurnout(veh, false)
            end

            local alpha = clamp(Config.RampRate * dt, 0.0, 1.0)
            currentTorqueMult = lerp(currentTorqueMult, targetTorque, alpha)
            SetVehicleEngineTorqueMultiplier(veh, currentTorqueMult)
        else
            if noSmokeApplied then
                restoreHandling(veh)
                noSmokeApplied = false
            end
            SetVehicleEngineTorqueMultiplier(veh, 1.0)
            currentTorqueMult = 1.0
        end

        ::continue::
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if activeVeh ~= 0 then
        SetVehicleEngineTorqueMultiplier(activeVeh, 1.0)
        restoreHandling(activeVeh)
        FreezeEntityPosition(activeVeh, false)
        SetVehicleUndriveable(activeVeh, false)
    end
end)
